<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auth - Worker Client</title>
</head>
<body>
    <div class="main">
        <h1>Auth - Worker</h1>
        <div class="auth">
            <a href="/auth/login">Login</a>
            <a href="/auth/register">Register</a>
        </div>
        
    </div>
</body>
</html>